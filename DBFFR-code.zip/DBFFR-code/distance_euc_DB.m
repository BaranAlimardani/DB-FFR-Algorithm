function [dist]= distance_euc(X,Y)
    for i=1:size(X,2)
        s = sum( abs(X(:,i) - Y).^ 2) ;
        dis(i) = s ^ (1/2);
    end
    dist = mean(dis);