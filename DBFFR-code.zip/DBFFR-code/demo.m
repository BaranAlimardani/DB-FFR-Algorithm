%---------------this package uses the DB-FFR algorithm in [1] to reduce the
%---------------number of features in a Data set 
%----------------input:
%----------------    Data set n*k:
%---------------      n: the number of samples
%---------------      k: the number of features
%---------------output:
%---------------      ordered vector of features according to DB-FFR algorithm
%-- [1] to reference please contact alimardani.f@gmail.com
function ranked_features=demo()
   %---load data
   d=load('sonar.txt');
   Data = d(:,2:end);
   Labels = d(1,:);
   %----Ranked features based on DB-FFR algorithm 
   [ranked] = DBFFR(Data,Labels);
   disp('Feature Ranking is done');
end


    





