function  [DBval] = DB(data,labels,FNO)
   cnum = unique(labels);
     for i=1:size(cnum,1)
         ci = find(labels==cnum(i));
         cdata{i}= data(ci,FNO);
         mu{i} = mean(data(ci,FNO));
         sigma{i} = cov(data(ci,FNO));
     end
     
% calculate davies Boldin*/
    for i=1: size(cnum,1)
        %--Find intra cluster dist
        di = distance_euc_DB(cdata{i},mu{i});
        maxval = -100;
        for j=1:size(cnum,1)
            if j==i
                continue;
            end
            dj = distance_euc_DB(cdata{j},mu{j});
            interdelta = distance_euc_DB(mu{i},mu{j});
            if (di+dj)/interdelta > maxval
                maxval = (di+dj)/interdelta;
            end
        end
        maxival(i) = maxval;
    end
    DBval = sum(maxival)/size(cnum,1);