function [s]= distance_manhatan(X,Y)
   s= sum(abs(X - Y));