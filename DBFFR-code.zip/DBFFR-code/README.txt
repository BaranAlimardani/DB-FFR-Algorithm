%---------------this package uses the DB-FFR algorithm in [1] to reduce the
%---------------number of features in a Data set 
%----------------input:
%----------------    Data set n*k:
%---------------      n: the number of samples
%---------------      k: the number of features
%---------------output:
%---------------      ordered vector of features according to DB-FFR algorithm
%-----------------------------------------------------------------------------
%-- [1]Alimardani, F., & Boostani, R. (2018). DB-FFR: a modified feature selection algorithm to improve discrimination rate between 
%------bipolar mood disorder (BMD) and schizophrenic patients. Iranian Journal of Science and Technology, Transactions of Electrical Engineering, 42(3), 251-260.

% The package is free to use, please refer to the paper as the ethical rule.