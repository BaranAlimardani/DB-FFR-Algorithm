function [val] = Calc_fitness(varargin)
%     length(varargin{1});
    data = varargin{1};
    f1 = varargin{2};
    if nargin == 3
       f2 = varargin{3};
       en1= calentropy(data(:,f1)');
       en2 = calentropy(data(:,f2)');
       val = (en2-calcondentropy(Data(:,f2)',Data(:,f1)') )/(en1+en2);
       else
        val = calentropy(data(:,f1)');
    end
    
end