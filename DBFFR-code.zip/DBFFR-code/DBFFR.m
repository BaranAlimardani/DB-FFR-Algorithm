%---data is n by k matrix 
%           n: number of samples
%           k: number of features
%--y is a vector of labels 
%          n by 1
function [ranked] = DBFFR(data,y)
%     data = load('C:\Fatima\Science\MSc\MSC-Codes\Datasets\Other\sonar.dat.in');
    k = size(data,2);
    for i=1:k
        vals(i) = DB(data,y,i);
    end
    [sortvals,ind] = sort(vals,'ascend');
    ranked(1) = ind(1);
    currf = ind(1);
    weigthmat = zeros(1,k);
    weigthmat(ind(1))=-1;
    sigma = 40;currind=2;
    ind(1)=-1;
    while (1==1)
        vals = [];
        for i=1:size(sortvals,2)
            if i==currf
                continue;
            end
            vals(i) = DB2(data,y,i,currf);
            if vals(i) > sortvals(i)
                weigthmat(i) = weigthmat(i) +1;
            end
        end
        %   redundant-features
        rr = find ((weigthmat >= sigma));
        ind(rr)=-1;
        nrr=find(ind ~= -1);
        if size(nrr,2)==0
            break;
        end
        currf = ind(nrr(1));
        ind(nrr(1))=-1;
        ranked = [ranked,currf];
        sortvals = vals;

    end

end