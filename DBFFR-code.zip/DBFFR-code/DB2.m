function  [DBval] = DB2(data,labels,FNO1,FNO2)
   cnum = unique(labels);
     for i=1:size(cnum,1)
         ci = find(labels==cnum(i));
         cdata{i}= data(ci,[FNO1,FNO2]);
         mu{i} = mean(data(ci,[FNO1,FNO2]));
         sigma{i} = cov(data(ci,[FNO1,FNO2]));
     end
     
% calculate davies Boldin*/
    for i=1: size(cnum,1)
        %--Find intra cluster dist
        for k=1:size(cdata{i},1)
            dik(k) = distance_euc_DB(cdata{i}(k,:),mu{i});
        end
        di = mean(dik);
        maxval = -100;
        for j=1:size(cnum,1)
            if j==i
                continue;
            end
            for k=1:size(cdata{j},1)
              djk(k) = distance_euc_DB(cdata{j}(k,:),mu{j});
            end
            dj = mean(djk);
            interdelta = distance_euc_DB(mu{i},mu{j});
            if (di+dj)/interdelta > maxval
                maxval = (di+dj)/interdelta;
            end
        end
        maxival(i) = maxval;
        clear dik;
        clear djk;
     end
    DBval = sum(maxival)/size(cnum,1);